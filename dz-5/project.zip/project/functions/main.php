<?php

require_once './functions/helper.php';
require_once './functions/Message.php';
require_once './functions/OldInputs.php';

session_start();

// action:sendEmail
$action = $_POST['action'] ?? null; // 'sendEmail'

if (!empty($action)) {
  $action(); // sendEmail()
}

function sendEmail()
{
  $name = clear($_POST['name'] ?? '');
  $phone = clear($_POST['phone'] ?? '');
  $message = clear($_POST['message'] ?? '');

  if (empty($name)) {
    Message::set('Name is required', 'danger');
    OldInputs::set($_POST);
    redirect('contacts');
  }

  if (empty($phone)) {
    Message::set('Phone is required', 'danger');
    OldInputs::set($_POST);
    redirect('contacts');
  }

  if (empty($message)) {
    Message::set('Message is required', 'danger');
    OldInputs::set($_POST);
    redirect('contacts');
  }



  mail('kudriashova.ag@gmail.com', 'Mail from site', "$name, $phone, $message");

  Message::set('Thank!');
  redirect('contacts');
}


function sendFile()
{
  //dump($_FILES['file']);
  extract($_FILES['file']); // деструктуризация 

  if ($error === 4) {
    Message::set('File is required', 'danger');
    redirect('uploads');
  }

  if ($error !== 0) {
    Message::set('File is not uploaded', 'danger');
    redirect('uploads');
  }

  $allowedFiles = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif'];
  if (!in_array($type, $allowedFiles)) {
    Message::set('File is not image', 'danger');
    redirect('uploads');
  }

  $ext = end(explode('.', $name));
  $fName = md5(time() . uniqid() . session_id()) . '.' . $ext;

  if (!file_exists('uploads'))
    mkdir('uploads');

  move_uploaded_file($tmp_name, './uploads/' . $fName);

  // изменение размеров изображения
  resizeImage('./uploads/' . $fName, 200, true);
  resizeImage('./uploads/' . $fName, 300, false);

  Message::set('File is uploaded!');
  redirect('uploads');
}


function resizeImage($filePath, $size, $crop)
{
  extract(pathinfo($filePath));
  $extension = strtolower($extension) === 'jpg' ? 'jpeg' : $extension;
  $functionCreate = 'imagecreatefrom' . $extension; // 'imagecreatefromjpeg'

  $src = $functionCreate($filePath);

  list($src_width, $src_height) = getimagesize($filePath);

  if ($crop) {
    // обрезка
    $dest = imagecreatetruecolor($size, $size);
    $filename .= "-{$size}x{$size}";
    if ($src_width > $src_height) {
      // если горизонтальное исх. изобр.
      imagecopyresized($dest, $src, 0, 0, $src_width / 2 - $src_height / 2, 0, $size, $size, $src_height, $src_height);
    } else {
      // если вертикальное исх. изобр.
      imagecopyresized($dest, $src, 0, 0, 0, $src_height / 2 - $src_width / 2, $size, $size, $src_width, $src_width);
    }
  } else {
    // пропорциональное изменение
    $dest_width = $size;
    $dest_height = round($dest_width / ($src_width / $src_height));

    $dest = imagecreatetruecolor($dest_width, $dest_height);
    $filename .= "-{$dest_width}x{$dest_height}";
    imagecopyresized($dest, $src, 0, 0, 0, 0, $dest_width, $dest_height, $src_width, $src_height);
  }

  $functionSave = 'image' . $extension;

  if(strtolower($extension) === 'jpg')
    imagejpeg($dest, "$dirname/$filename.$extension", 100); // сохранение изображения
  else
    $functionSave($dest, "$dirname/$filename.$extension");
}
